# Doctor Window

## Features
1. View patient's appointments & previous records
2. Start consult and generate prescriptions
3. View timetable
4. View & Edit personal information
5. Reset password
