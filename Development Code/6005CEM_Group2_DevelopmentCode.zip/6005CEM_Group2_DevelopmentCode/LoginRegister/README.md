# Login and Register

## Features
1. Get started
2. Normal user / Clinic / Doctor / Admin Login
3. Normal user registration
4. Clinic registration
5. Forgot password
