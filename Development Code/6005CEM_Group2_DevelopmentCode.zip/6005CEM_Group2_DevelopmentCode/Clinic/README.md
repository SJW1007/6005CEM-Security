# Clinic Window

## Features
1. View & Accept/Reject patient's appoinments
2. Assign doctor if necessary
3. View doctors' timetable
4. View & Edit doctor information
5. Add / Remove a doctor
6. View & Edit personal information
7. Reset password
8. Submit rejoin / leave request to admin
