# Admin Window

## Features
1. View clinic list (all clinics)
2. View & Accept/Reject clinic's requests
3. Reset password
