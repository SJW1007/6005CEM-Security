# Import RateLimiter from the security.py module file to make it available from the security package
import importlib.util
import os

# Get the path to security.py in the parent directory
_parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_security_module_path = os.path.join(_parent_dir, "security.py")

if os.path.exists(_security_module_path):
    spec = importlib.util.spec_from_file_location("security_module", _security_module_path)
    security_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(security_module)
    RateLimiter = security_module.RateLimiter
else:
    # Fallback if security.py doesn't exist
    RateLimiter = None




