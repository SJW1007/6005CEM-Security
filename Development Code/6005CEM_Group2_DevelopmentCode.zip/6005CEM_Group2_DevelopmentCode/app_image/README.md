# Images used in the application

## Used for
1. Background
2. Icon
3. Button
