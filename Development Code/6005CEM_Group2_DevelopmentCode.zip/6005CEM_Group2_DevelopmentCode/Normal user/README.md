# Normal user Window

## Features
1. View clinic list
2. Search clinic based on name or address
3. Book schedule
4. View appointments
5. View & Edit personal information
6. Reset password
